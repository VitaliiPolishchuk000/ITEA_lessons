//
//  ViewController.swift
//  Hello Word
//
//  Created by Vitalii on 24.04.2020.
//  Copyright © 2020 Vitalii Polishchuk. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
        label.backgroundColor = UIColor.yellow
        label.center = CGPoint(x: 180, y: 285)
        label.textAlignment = .center
        label.text = "Hello World"
        self.view.addSubview(label)
    
    }
}


